var configuracion = [
  ["1s^2"],
  ["2s^2","2p^6"],
  ["3s^2","3p^6","3d^10"],
  ["4s^2","4p^6","4d^10","4f^14"],
  ["5s^2","5p^6","5d^10","5f^14"],
  ["3s^2","3p^6","3d^10"],
  ["7s^2","7p^6"]
];


for (var i = 0; i < configuracion.length; i++) {
  var linea = ""; 
  for (var j = 0; j < configuracion[i].length; j++) {
    if (j > 0) linea += " ";
    linea += configuracion[i][j];
  }
  console.log(linea); 
}
console.log("-----");
console.log("Épico");