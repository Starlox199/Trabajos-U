const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );

const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
renderer.setAnimationLoop( animate );
document.body.appendChild( renderer.domElement );

const geometry = new THREE.CylinderGeometry( 1, 1, 0.2, 32 );
const material = new THREE.MeshBasicMaterial( { color: 0x9D720E } );
const cylinder = new THREE.Mesh( geometry, material );
scene.add( cylinder );


camera.position.z=5

let clicks = 0;
let clicksPorClick = 1;
let clicksPorSegundo = 0;

const clickDisplay = document.getElementById("clickCount");
const btnMejora1 = document.getElementById("mejora1");
const btnMejora2 = document.getElementById("mejora2");
const btnMejora3 = document.getElementById("mejora3");

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

function onMouseClick(event) {
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObjects(scene.children);

  if (intersects.length > 0 && intersects[0].object === cylinder) {
    clicks += clicksPorClick;
    actualizarContador();
  }
}
window.addEventListener("click", onMouseClick);

// Botones de mejora 
btnMejora1.addEventListener("click", () => {
  if (clicks >= 50) {
    clicks -= 50;
    clicksPorSegundo += 1;
    actualizarContador();
  }
});

btnMejora2.addEventListener("click", () => {
  if (clicks >= 150) {
    clicks -= 150;
    clicksPorClick = 2;
    actualizarContador();
  }
});

btnMejora3.addEventListener("click", () => {
  if (clicks >= 300) {
    clicks -= 300;
    clicksPorSegundo += 2;
    actualizarContador();
  }
});

// Clicks automáticos
setInterval(() => {
  clicks += clicksPorSegundo;
  actualizarContador();
}, 1000);

function actualizarContador() {
  clickDisplay.textContent = clicks;
}

function animate() {
  cylinder.rotation.y += 0.01;
  cylinder.rotation.x += 0.01;
  renderer.render(scene, camera);
}
