const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setAnimationLoop(animate);
document.body.appendChild(renderer.domElement);

const geometry = new THREE.CircleGeometry(0.7, 32);
const material = new THREE.MeshBasicMaterial({ color: 0x00FFFF });
const circle = new THREE.Mesh(geometry, material);
scene.add(circle);

camera.position.z = 30;

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const clickDisplay = document.getElementById("clickCount");

var currentCircle = circle;
var clicks = 0;
var t = 0;
var velocidad = 0.01;
var movimiento = "vertical"; 


function onMuouseMove(event) {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
}
window.addEventListener('mousemove', onMuouseMove, false);

function minitargets() {
    const geometry = new THREE.CircleGeometry(0.7, 32);
    const material = new THREE.MeshBasicMaterial({ color: 0x00FFFF });
    const circle = new THREE.Mesh(geometry, material);
    scene.add(circle);
    circle.position.x = Math.random() * 15;
    circle.position.y = Math.random() * 15;
    currentCircle = circle;
    movimiento = Math.random() < 0.5 ? "vertical" : "horizontal";
}

function disparo(objeto) {
    scene.remove(objeto);
    clicks += 1;
    clickDisplay.textContent = clicks;
    velocidad += 0.01;
    t = 0;
    setTimeout(() => {
        minitargets();
    }, 500);
}

window.addEventListener("click", (event) => {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObjects(scene.children);
    if (intersects.length > 0) {
        const obj = intersects[0].object;
        disparo(obj);
    }
});

function animate() {
    t += velocidad;
    if (movimiento === "vertical") {
        currentCircle.position.y = 10 * Math.sin(t);
    } else {
        currentCircle.position.x = 10 * Math.cos(t);
    }
    renderer.render(scene, camera);
}
animate();
