const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const luz = new THREE.AmbientLight(0xffffff, 0.7);
scene.add(luz);

const luzPunto = new THREE.PointLight(0xffffff, 1);
luzPunto.position.set(10, 10, 10);
scene.add(luzPunto);


const geometry = new THREE.SphereGeometry(0.7, 32, 32);
const material = new THREE.MeshStandardMaterial({ color: 0xCC0000 });
const circle = new THREE.Mesh(geometry, material);
scene.add(circle);

camera.position.z = 30;

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const clickDisplay = document.getElementById("clickCount");
const countdownDiv = document.getElementById("countdown");


const loader = new THREE.TextureLoader();
loader.load(
    "https://static.vecteezy.com/system/resources/previews/017/775/788/non_2x/white-and-gray-chequered-pattern-for-transparent-background-vector.jpg",
    tex => scene.background = tex
);

var currentCircle = null; 
var clicks = 0;
var t = 0;
var velocidad = 0.01;
var movimiento = "vertical";
var juegoIniciado = false;
var countdownNumero = 3;

function onMuouseMove(event) {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
}
window.addEventListener('mousemove', onMuouseMove, false);


function minitargets() {
    const geometry = new THREE.SphereGeometry(0.7, 32, 32);
    const material = new THREE.MeshStandardMaterial({ color: 0xCC0000 });
    const circle = new THREE.Mesh(geometry, material);
    scene.add(circle);

    circle.position.x = Math.random() * 15;
    circle.position.y = Math.random() * 15;

    currentCircle = circle;
    movimiento = Math.random() < 0.5 ? "vertical" : "horizontal";
}


function disparo(objeto) {
    scene.remove(objeto);
    clicks += 1;
    clickDisplay.textContent = clicks;
    velocidad += 0.001;
    t = 0;

    setTimeout(() => {
        minitargets();
    }, 500);
}

window.addEventListener("click", (event) => {
    if (!juegoIniciado) return;

    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObjects(scene.children);

    if (intersects.length > 0) {
        disparo(intersects[0].object);
    }
});


function iniciarCuentaRegresiva() {

    countdownDiv.style.color = "black"; 

    const interval = setInterval(() => {

        countdownDiv.textContent = countdownNumero;

        if (countdownNumero === 0) {
            countdownDiv.textContent = "COMIENZA!";
        }

        if (countdownNumero < 0) {
            clearInterval(interval);
            countdownDiv.style.display = "none";

            scene.remove(circle);

            juegoIniciado = true;
            minitargets();
        }

        countdownNumero--;

    }, 1000);
}

function animate() {
    requestAnimationFrame(animate);

    if (juegoIniciado && currentCircle) {
        t += velocidad;

        if (movimiento === "vertical") {
            currentCircle.position.y = 20 * Math.sin(t);
        } else {
            currentCircle.position.x = 20 * Math.cos(t);
        }
    }

    renderer.render(scene, camera);
}

animate();
iniciarCuentaRegresiva();
