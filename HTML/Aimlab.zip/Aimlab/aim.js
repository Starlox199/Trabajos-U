const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );

const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
renderer.setAnimationLoop( animate );
document.body.appendChild( renderer.domElement );

const geometry = new THREE.CircleGeometry( 0.5, 32 );
const material = new THREE.MeshBasicMaterial( { color: 0x00FFFF } );
const circle = new THREE.Mesh( geometry, material );
scene.add( circle )

camera.position.z = 30;

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
var isActive=false;

setTimeout(() =>{
    console.log("Ya se puede disparar")
    isActive=true;
},"10");


function onMuouseMove(event){
    mouse.x=(event.clientX / window.innerWidth) * 2-1;
    mouse.y=-(event.clientY / window.innerHeight) * 2+1;
}
window.addEventListener('mousemove', onMuouseMove,false);

isCreate=true;
function minitargets(){
    const geometry = new THREE.CircleGeometry( 0.5, 32 );
    const material = new THREE.MeshBasicMaterial( { color: 0x00FFFF } );
    const circle = new THREE.Mesh( geometry, material );
    scene.add( circle )
    circle.position.x=Math.random()*15
    circle.position.y=Math.random()*15
}

function disparo(objeto){
    scene.remove(objeto);
    t=0;
    setTimeout(() =>{
        minitargets();
    },"500");
}

var t=0;
function animate() {

    requestAnimationFrame(animate);
    t+=0.001;
    circle.position.y=10*Math.sin(t*0.1);
    onmousedown=(event=>{
        console.log("Click")
        
        raycaster.setFromCamera(mouse,camera);
    const intersects= raycaster.intersectObjects(scene.children,true);
    
    if(intersects.length > 0 ){
        const firstIntersectedObject=intersects[0].object;
        //firstIntersectedObject.position.y=2;
        disparo(firstIntersectedObject);
    }
})



  renderer.render( scene, camera );

}