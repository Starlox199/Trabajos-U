const Baner=document.getElementById("banner")

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, banner.clientWidth / banner.clientHeight, 0.1, 1000 );

const renderer = new THREE.WebGLRenderer();
renderer.setSize( banner.clientWidth, banner.clientHeight );
renderer.setAnimationLoop( animate );
banner.appendChild( renderer.domElement );

const geometry = new THREE.SphereGeometry( 60, 32, 16 ); 
const material = new THREE.MeshBasicMaterial( { color: 0xffff00 } ); 
const sol = new THREE.Mesh( geometry, material ); 
scene.add( sol );

const geometry1 = new THREE.SphereGeometry( 3, 32, 16 ); ; 
const material1 = new THREE.MeshBasicMaterial( { color: 0xC58E56 } ); 
const mercurio = new THREE.Mesh( geometry1, material1 ); 
scene.add( mercurio );
const geometry3_21 = new THREE.SphereGeometry( 1, 32, 16 ); 
const material3_21 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const lunant = new THREE.Mesh( geometry3_21, material3_21 ); 
scene.add( lunant );
const geometry3_22 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_22 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const lunala = new THREE.Mesh( geometry3_22, material3_22 ); 
scene.add( lunala );

const geometry4 = new THREE.SphereGeometry( 4, 32, 16 ); ; 
const material4 = new THREE.MeshBasicMaterial( { color: 0xE69138 } ); 
const venus = new THREE.Mesh( geometry4, material4 ); 
scene.add( venus );
const geometry3_23 = new THREE.SphereGeometry( 0.7, 32, 16 ); 
const material3_23 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const feiklunant = new THREE.Mesh( geometry3_23, material3_23 ); 
scene.add( feiklunant );
const geometry3_24 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_24 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const feiklunala = new THREE.Mesh( geometry3_24, material3_24 ); 
scene.add( feiklunala );
const geometry3_25 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_25 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const feikluna = new THREE.Mesh( geometry3_25, material3_25 ); 
scene.add( feikluna );

const geometry2 = new THREE.SphereGeometry( 5, 32, 16 ); ; 
const material2 = new THREE.MeshBasicMaterial( { color: 0x008CFF } ); 
const tierra = new THREE.Mesh( geometry2, material2 ); 
scene.add( tierra );
const geometry3 = new THREE.SphereGeometry( 1, 32, 16 ); 
const material3 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const luna = new THREE.Mesh( geometry3, material3 ); 
scene.add( luna );

const geometry5 = new THREE.SphereGeometry( 5, 32, 16 ); ; 
const material5 = new THREE.MeshBasicMaterial( { color: 0x990000 } ); 
const marte = new THREE.Mesh( geometry5, material5 ); 
scene.add( marte );
const geometry3_1 = new THREE.SphereGeometry( 1, 32, 16 ); 
const material3_1 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const fobos = new THREE.Mesh( geometry3_1, material3_1 ); 
scene.add( fobos );
const geometry3_2 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_2 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const deimos = new THREE.Mesh( geometry3_2, material3_2 ); 
scene.add( deimos );


const geometry6 = new THREE.RingGeometry( 200, 210, 30 ); 
const material6 = new THREE.MeshBasicMaterial( { color: 0x979797, side: THREE.DoubleSide } );
const asteroides = new THREE.Mesh( geometry6, material6 );
scene.add( asteroides );

const geometry7 = new THREE.SphereGeometry( 10, 32, 16 ); ; 
const material7 = new THREE.MeshBasicMaterial( { color: 0xE69138 } ); 
const jupiter = new THREE.Mesh( geometry7, material7 ); 
scene.add( jupiter );
const geometry3_3 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_3 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const europa = new THREE.Mesh( geometry3_3, material3_3 ); 
scene.add( europa );
const geometry3_4 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_4 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const io = new THREE.Mesh( geometry3_4, material3_4 ); 
scene.add( io );
const geometry3_5 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_5 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const ganimedes = new THREE.Mesh( geometry3_5, material3_5 ); 
scene.add( ganimedes );

const geometry8 = new THREE.SphereGeometry( 8, 32, 32 ); ; 
const material8 = new THREE.MeshBasicMaterial( { color: 0xEBA760 } ); 
const saturno = new THREE.Mesh( geometry8, material8 ); 
scene.add( saturno );
const geometry9 = new THREE.RingGeometry( 17, 21, 30 ); 
const material9 = new THREE.MeshBasicMaterial( { color: 0xF2C799, side: THREE.DoubleSide } );
const astsaturno = new THREE.Mesh( geometry9, material9 );
scene.add( astsaturno );
const geometry3_6 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_6 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const titan = new THREE.Mesh( geometry3_6, material3_6 ); 
scene.add( titan );
const geometry3_7 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_7 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const encelado = new THREE.Mesh( geometry3_7, material3_7 ); 
scene.add( encelado );
const geometry3_8 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_8 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const mimas = new THREE.Mesh( geometry3_8, material3_8 ); 
scene.add( mimas );
const geometry3_9 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_9 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const dione = new THREE.Mesh( geometry3_9, material3_9 ); 
scene.add( dione );

const geometry10 = new THREE.SphereGeometry( 7, 32, 32 ); ; 
const material10 = new THREE.MeshBasicMaterial( { color: 0x6FA8DC } ); 
const urano = new THREE.Mesh( geometry10, material10 ); 
scene.add( urano );
const geometry3_10 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_10 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const umbriel = new THREE.Mesh( geometry3_10, material3_10 ); 
scene.add( umbriel );
const geometry3_11 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_11 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const titania = new THREE.Mesh( geometry3_11, material3_11 ); 
scene.add( titania );
const geometry3_12 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_12 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const miranda = new THREE.Mesh( geometry3_12, material3_12 ); 
scene.add( miranda );
const geometry3_13 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_13 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const oberon = new THREE.Mesh( geometry3_13, material3_13 ); 
scene.add( oberon );
const geometry3_14 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_14 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const ariel = new THREE.Mesh( geometry3_14, material3_14 ); 
scene.add( ariel );

const geometry11 = new THREE.SphereGeometry( 7, 32, 32 ); ; 
const material11 = new THREE.MeshBasicMaterial( { color: 0x3A3ABF } ); 
const neptuno = new THREE.Mesh( geometry11, material11 ); 
scene.add( neptuno );
const geometry3_15 = new THREE.SphereGeometry( 0.7, 32, 16 ); 
const material3_15 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const triton = new THREE.Mesh( geometry3_15, material3_15 ); 
scene.add( triton );
const geometry3_16 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_16 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const talasa = new THREE.Mesh( geometry3_16, material3_16 ); 
scene.add( talasa );
const geometry3_17 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_17 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const hipocampo = new THREE.Mesh( geometry3_17, material3_17 ); 
scene.add( hipocampo );
const geometry3_18 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_18 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const nereida = new THREE.Mesh( geometry3_18, material3_18 ); 
scene.add( nereida );
const geometry3_19 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_19 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const galatea = new THREE.Mesh( geometry3_19, material3_19 ); 
scene.add( galatea );
const geometry3_20 = new THREE.SphereGeometry( 0.5, 32, 16 ); 
const material3_20 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const despina = new THREE.Mesh( geometry3_12, material3_12 ); 
scene.add(despina);
const loader = new THREE.TextureLoader();
loader.load(
    "https://res.cloudinary.com/dmcvdsh4c/image/upload/v1731955523/iceebook/espacio/espacio-exterior-que-es-caracteristicas-composicion_bno85b.webp",
    tex => { scene.background = tex; }
);




const radioMerc=100
const radioLunant=7
const radioLunala=3

const radioVenus=125
const radioFeikLunant=9
const radioFeikLunala=3
const radioFeikLuna=4

const radioTierra=150
const radioLuna=10

const radioMarte=175
const radioFobos=8
const radioDeimos=11

const radioJupiter=250
const radioEuropa=15
const radioIo=18
const radioGanimedes=20

const radioSaturno=320
const radioTitan=24
const radioEncelado=26
const radioMimas=28
const radioDione=30

const radioUrano=390
const radioUmbriel=13
const radioTitania=15
const radioMiranda=17
const radioOberon=19
const radioAriel=21

const radioNeptuno=450
const radioTriton=13
const radioTalasa=15
const radioHipocampo=17
const radioNereida=19
const radioGalatea=21
const radioDespina=23


let t=0;
let p=0;
camera.position.z = 370;

function animate() {

   sol.position.x=0;
   sol.position.y=0;

   mercurio.position.x=radioMerc*Math.cos(t*0.7)
   mercurio.position.y=radioMerc*Math.sin(t*0.7)
   lunant.position.x=mercurio.position.x+radioLunant*Math.cos(p*0.5)   
   lunant.position.y=mercurio.position.y+radioLunant*Math.sin(p*0.5)
   lunala.position.x=lunant.position.x+radioLunala*Math.cos(p*0.7)   
   lunala.position.y=lunant.position.y+radioLunala*Math.sin(p*0.7)

   venus.position.x=radioVenus*Math.cos(t*0.5)
   venus.position.y=radioVenus*Math.sin(t*0.5)
   feiklunant.position.x=venus.position.x+radioFeikLunant*Math.cos(p*0.5)   
   feiklunant.position.y=venus.position.y+radioFeikLunant*Math.sin(p*0.5)
   feiklunala.position.x=feiklunant.position.x+radioFeikLunala*Math.cos(p*0.7)   
   feiklunala.position.y=feiklunant.position.y+radioFeikLunala*Math.sin(p*0.7)
   feikluna.position.x=feiklunant.position.x+radioFeikLuna*Math.sin(p*0.7)   
   feikluna.position.y=feiklunant.position.y+radioFeikLuna*Math.cos(p*0.7)

   tierra.position.x=radioTierra*Math.cos(t*0.3)
   tierra.position.y=radioTierra*Math.sin(t*0.3)
   luna.position.x=tierra.position.x+radioLuna*Math.cos(p*0.5)
   luna.position.y=tierra.position.y+radioLuna*Math.sin(p*0.5)

   marte.position.x=radioMarte*Math.cos(t*0.25)
   marte.position.y=radioMarte*Math.sin(t*0.25)
   fobos.position.x=marte.position.x+radioFobos*Math.cos(p*0.7)
   fobos.position.y=marte.position.y+radioFobos*Math.sin(p*0.7)
   deimos.position.x=marte.position.x+radioDeimos*Math.cos(p*0.4)
   deimos.position.y=marte.position.y+radioDeimos*Math.sin(p*0.4)

   asteroides.rotation.z+=0.005

   jupiter.position.x=radioJupiter*Math.cos(t*0.2)
   jupiter.position.y=radioJupiter*Math.sin(t*0.2)
   europa.position.x=jupiter.position.x+radioEuropa*Math.cos(p*0.42)
   europa.position.y=jupiter.position.y+radioEuropa*Math.sin(p*0.42)
   io.position.x=jupiter.position.x+radioIo*Math.cos(p*0.41)
   io.position.y=jupiter.position.y+radioIo*Math.sin(p*0.41)
   ganimedes.position.x=jupiter.position.x+radioGanimedes*Math.cos(p*0.4)
   ganimedes.position.y=jupiter.position.y+radioGanimedes*Math.sin(p*0.4)

   saturno.position.x=radioSaturno*Math.cos(t*0.14)
   saturno.position.y=radioSaturno*Math.sin(t*0.14)
   astsaturno.position.x=radioSaturno*Math.cos(t*0.14)
   astsaturno.position.y=radioSaturno*Math.sin(t*0.14)
   titan.position.x=saturno.position.x+radioTitan*Math.cos(p*0.43)
   titan.position.y=saturno.position.y+radioTitan*Math.sin(p*0.43)
   encelado.position.x=saturno.position.x+radioEncelado*Math.cos(p*0.42)
   encelado.position.y=saturno.position.y+radioEncelado*Math.sin(p*0.42)
   mimas.position.x=saturno.position.x+radioMimas*Math.cos(p*0.41)
   mimas.position.y=saturno.position.y+radioMimas*Math.sin(p*0.41)
   dione.position.x=saturno.position.x+radioDione*Math.cos(p*0.4)
   dione.position.y=saturno.position.y+radioDione*Math.sin(p*0.4)

   urano.position.x=radioUrano*Math.cos(t*0.09)
   urano.position.y=radioUrano*Math.sin(t*0.09)
   umbriel.position.x=urano.position.x+radioUmbriel*Math.cos(p*0.44)
   umbriel.position.y=urano.position.y+radioUmbriel*Math.sin(p*0.44)
   titania.position.x=urano.position.x+radioTitania*Math.cos(p*0.43)
   titania.position.y=urano.position.y+radioTitania*Math.sin(p*0.43)
   miranda.position.x=urano.position.x+radioMiranda*Math.cos(p*0.42)
   miranda.position.y=urano.position.y+radioMiranda*Math.sin(p*0.42)
   oberon.position.x=urano.position.x+radioOberon*Math.cos(p*0.41)
   oberon.position.y=urano.position.y+radioOberon*Math.sin(p*0.41)
   ariel.position.x=urano.position.x+radioAriel*Math.cos(p*0.4)
   ariel.position.y=urano.position.y+radioAriel*Math.sin(p*0.4)


   neptuno.position.x=radioNeptuno*Math.cos(t*0.07)
   neptuno.position.y=radioNeptuno*Math.sin(t*0.07)
   triton.position.x=neptuno.position.x+radioTriton*Math.cos(p*0.45)
   triton.position.y=neptuno.position.y+radioTriton*Math.sin(p*0.45)
   talasa.position.x=neptuno.position.x+radioTalasa*Math.cos(p*0.44)
   talasa.position.y=neptuno.position.y+radioTalasa*Math.sin(p*0.44)
   hipocampo.position.x=neptuno.position.x+radioHipocampo*Math.cos(p*0.43)
   hipocampo.position.y=neptuno.position.y+radioHipocampo*Math.sin(p*0.43)
   nereida.position.x=neptuno.position.x+radioNereida*Math.cos(p*0.42)
   nereida.position.y=neptuno.position.y+radioNereida*Math.sin(p*0.42)
   galatea.position.x=neptuno.position.x+radioGalatea*Math.cos(p*0.41)
   galatea.position.y=neptuno.position.y+radioGalatea*Math.sin(p*0.41)
   despina.position.x=neptuno.position.x+radioDespina*Math.cos(p*0.4)
   despina.position.y=neptuno.position.y+radioDespina*Math.sin(p*0.4)
   
   
   
    t+=0.1
    p+=0.1
    renderer.render( scene, camera );

}
function crearMiniPlaneta(contenedor, color, size) {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, contenedor.clientWidth / contenedor.clientHeight, 0.1, 100);
    const renderer = new THREE.WebGLRenderer({ alpha: true });
    renderer.setSize(contenedor.clientWidth, contenedor.clientHeight);
    contenedor.appendChild(renderer.domElement);

    const geo = new THREE.SphereGeometry(size, 32, 32);
    const mat = new THREE.MeshStandardMaterial({ color });
    const planeta = new THREE.Mesh(geo, mat);
    scene.add(planeta);

    const luz = new THREE.PointLight(0xffffff, 1);
    luz.position.set(5, 5, 5);
    scene.add(luz);

    camera.position.z = size * 4;

    function animate() {
        planeta.rotation.y += 0.01;
        renderer.render(scene, camera);
        requestAnimationFrame(animate);
    }
    animate();
}

document.querySelectorAll(".planet-3d").forEach(div => {
    const tipo = div.dataset.planet;

    if (tipo === "mercurio") crearMiniPlaneta(div, 0xC58E56, 1.5);
    if (tipo === "venus")    crearMiniPlaneta(div, 0xE69138, 2);
    if (tipo === "tierra")   crearMiniPlaneta(div, 0x008CFF, 2.2);
    if (tipo === "marte")    crearMiniPlaneta(div, 0x990000, 2.1);
    if (tipo === "jupiter")  crearMiniPlaneta(div, 0xE69138, 4);
    if (tipo === "saturno") crearMiniSaturno(div);
    if (tipo === "urano")    crearMiniPlaneta(div, 0x6FA8DC, 3);
    if (tipo === "neptuno")  crearMiniPlaneta(div, 0x3A3ABF, 3);
});

function crearMiniSaturno(contenedor) {
    const escena = new THREE.Scene();
    const cam = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    const renderer = new THREE.WebGLRenderer({ alpha: true });
    renderer.setSize(220, 220);
    contenedor.appendChild(renderer.domElement);

    const luz = new THREE.DirectionalLight(0xffffff, 1.2);
    luz.position.set(5, 5, 5);
    escena.add(luz);

    const planetaGeo = new THREE.SphereGeometry(1, 32, 32);
    const planetaMat = new THREE.MeshStandardMaterial({ color: 0xF2C799 });
    const planeta = new THREE.Mesh(planetaGeo, planetaMat);

    const grupo = new THREE.Group();
    grupo.add(planeta);

    
    const inner = 1.4;
    const outer = 2.2;

    const anilloGeom = new THREE.RingGeometry(inner, outer, 64);
    const anilloMat = new THREE.MeshStandardMaterial({
        color: 0xD8C497,
        side: THREE.DoubleSide
    });

    const anillo = new THREE.Mesh(anilloGeom, anilloMat);

    anillo.rotation.x = (Math.PI / 2)*0.3;
    anillo.position.y = -0.1; 


    grupo.add(anillo);
    escena.add(grupo);

    cam.position.z = 6;

    function animar() {
        requestAnimationFrame(animar);
        grupo.rotation.y += 0.01;
        renderer.render(escena, cam);
    }
    animar();
}




