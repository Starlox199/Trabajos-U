const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );

const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
renderer.setAnimationLoop( animate );
document.body.appendChild( renderer.domElement );

const geometry = new THREE.SphereGeometry( 20, 32, 16 ); 
const material = new THREE.MeshBasicMaterial( { color: 0xffff00 } ); 
const sol = new THREE.Mesh( geometry, material ); 
scene.add( sol );

const geometry2 = new THREE.SphereGeometry( 5, 32, 16 ); ; 
const material2 = new THREE.MeshBasicMaterial( { color: 0x008CFF } ); 
const tierra = new THREE.Mesh( geometry2, material2 ); 
scene.add( tierra );

const geometry3 = new THREE.SphereGeometry( 1, 32, 16 ); 
const material3 = new THREE.MeshBasicMaterial( { color: 0x979797 } ); 
const luna = new THREE.Mesh( geometry3, material3 ); 
scene.add( luna );


const posol=30;
const radioTierra=40
const radioLuna=10
let t=0;
camera.position.z = 25;

function animate() {

   sol.position.x=30;
   sol.position.y=0;

   tierra.position.x=posol+radioTierra*Math.cos(t*0.1)
   tierra.position.y=radioTierra*Math.sin(t*0.1)

   luna.position.x=tierra.position.x+radioLuna*Math.cos(t*0.5)
   luna.position.y=tierra.position.y+radioLuna*Math.sin(t*0.5)

    t+=0.1

    
    
    renderer.render( scene, camera );

}
