// CONTADOR DE PRODUCTOS 
var contadores = document.getElementsByClassName("contador-productos");

for (var i = 0; i < contadores.length; i++) {
  (function(index) {
    var contador = 0;
    var contadorElemento = contadores[index].getElementsByClassName("contador")[0];
    var btnSumar = contadores[index].getElementsByClassName("btnSumar")[0];
    var btnRestar = contadores[index].getElementsByClassName("btnRestar")[0];

    btnSumar.addEventListener("click", function() {
      contador++;
      contadorElemento.textContent = contador;
    });

    btnRestar.addEventListener("click", function() {
      if (contador > 0) {
        contador--;
        contadorElemento.textContent = contador;
      }
    });
  })(i);
}


// CAMBIO DE IDIOMA
var botonIdioma = document.getElementById("cambiarIdioma");
var idiomaActual = "es"; // español por defecto

botonIdioma.addEventListener("click", function() {
  var titulos = document.querySelectorAll(".traduccion");

  if (idiomaActual === "es") {
    for (var i = 0; i < titulos.length; i++) {
      titulos[i].innerText = titulos[i].dataset.en; 
    }
    idiomaActual = "en";
    botonIdioma.textContent = "Cambiar a Español";
  } else {
    for (var i = 0; i < titulos.length; i++) {
      titulos[i].innerText = titulos[i].dataset.es; 
    }
    idiomaActual = "es";
    botonIdioma.textContent = "Change to English";
  }
});


// CAMBIO DE IMAGEN
var slides = document.querySelectorAll('.slide');
var currentIndex = 0;


function showSlide(index) {
  slides.forEach(function(slide) {
    slide.classList.remove('active');
  });
  slides[index].classList.add('active');
}

document.querySelector('.next').onclick = function() {
  currentIndex = (currentIndex + 1) % slides.length;
  showSlide(currentIndex);
};

document.querySelector('.prev').onclick = function() {
  currentIndex = (currentIndex - 1 + slides.length) % slides.length;
  showSlide(currentIndex);
};
